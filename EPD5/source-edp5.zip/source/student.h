


void searchTemplate(cv::Mat &in, cv::Mat &temp, cv::Mat &out);

cv::Vec3f transfromToWorldCoordinates(float u, float v, float depth, sensor_msgs::CameraInfo calib);

void processImageAndDepth(cv::Mat &img, cv::Mat &depth, cv::Mat &out);


